from sentinet.kermit import *
from time import sleep

if __name__ == '__main__':
    a = KermitControlModule()
    sleep(20)
    a.quit_kermit()

