/**
 * @author      : theo (theo@$HOSTNAME)
 * @file        : kermit_control
 * @created     : Sunday Oct 13, 2019 14:35:38 MDT
 */

#include "scpp/kernel/KermitControlModule.hpp"

// TODO
int
main()
{
  return 1;
}
