/**
 * @author      : theo (theo@$HOSTNAME)
 * @file        : main2
 * @created     : Tuesday Oct 01, 2019 10:31:07 MDT
 */

#include "scpp/standards.h"
#include <stdio.h>

int
main()
{

  return 0;
}
